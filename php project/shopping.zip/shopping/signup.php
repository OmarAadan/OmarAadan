<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Form</title>
    <style>
        .signup {
            width: 460px;
            margin: 58px auto;
            font-family: Georgia;
            border-radius: 10px;
            border: 2px solid #009;
            padding: 10px 40px 10px;
            margin-top: 100px;
        }

        input[type="text"],
        input[type="password"] {
            width: 90%;
            padding: 5px;
            margin-top: 2px;
            margin-bottom: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            padding-left: 5px;
            font-size: 16px;
            font-family: Georgia;
        }

        input[type="file"] {
            width: 90%;
            margin-top: 8px;
            margin-bottom: 15px;
        }

        input[type="submit"] {
            width: 100%;
            background-color: #fff;
            color: #009;
            border: 2px solid #009;
            padding: 7px;
            font-size: 20px;
            cursor: pointer;
            border-radius: 5px;
            margin-bottom: 5px;
            font-weight: bold;
        }

        label {
            font-weight: bold;
        }

        h1 {
            text-align: center;
        }

        span {
            color: red;
            text-align: center;
            display: block;
        }

        fieldset {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<?php
$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit'])) {
    $fullname = $_POST['fullname'];
    $sex = $_POST['sex'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $profile_picture = ''; // Placeholder for profile picture, you'll need to handle file upload separately
    $user_type = $_POST['user_type'];

    // Your database connection code goes here
    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "shop_e"; // Change this if your database name is different

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $sql = "INSERT INTO login (fullname, sex, username, password, phone, email, profile_picture, user_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $fullname, $sex, $username, $password, $phone, $email, $profile_picture, $user_type);

    if ($stmt->execute()) {
        $message = "Signup successful! You can now login.";
        header("Location: login.php"); // Redirect to the login page
        exit(); // Make sure to exit to prevent further execution of the script
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<div class="signup">
    <h1>Signup Form</h1>
    <form method="post" action="" enctype="multipart/form-data">
        <label for="fullname">Full Name:</label>
        <input type="text" name="fullname" id="fullname" required>

        <label for="sex">Sex:</label>
        <input type="text" name="sex" id="sex" required>

        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required>
        
        <label for="email">Email:</label>
        <input type="text" name="email" id="email" required>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>

        <label for="phone">Phone:</label>
        <input type="text" name="phone" id="phone" required>

        <fieldset>
            <legend>User Type</legend>
            <label for="user_type">Select User Type:</label>
            <select name="user_type" id="user_type" required>
                <option value="customer">User</option>
                <option value="admin">Admin</option>
                <!-- Add more options as needed -->
            </select>
        </fieldset>

        <label for="profile_picture">Profile Picture:</label>
        <input type="file" name="profile_picture" id="profile_picture" accept="image/*">

        <br><br>
        <input type="submit" name="submit" value="Signup">
    </form>
    <?php echo "<span>$message</span>"; ?>
</div>

</body>
</html>
