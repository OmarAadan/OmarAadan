<?php
session_start();
include 'db_connection.php';

// Check if the user is an admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle the admin form submission
    // (You can add code to process the admin form data)
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <!-- Include the Tailwind CSS file -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>

<body class="bg-gray-100">
    <!-- Your navigation bar code here -->
    <?php include 'admin_navbar.php'; ?>

    <div class="container mx-auto mt-8">
        <h2 class="text-4xl font-bold mb-4">Admin Page</h2>
        <!-- Your admin form code here -->
        <form action="admin.php" method="post" enctype="multipart/form-data">
            <!-- Form fields go here -->
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Submit Admin Request</button>
        </form>
    </div>

    <<footer class="bg-gray-800 text-white py-4 text-center">
    <div class="container mx-auto">
        &copy; 2023 puplished this Electronic shop | All rights reserved | Developed by Omar Adan and Zakaria Mahad
    </div>
</footer>
</body>

</html>
