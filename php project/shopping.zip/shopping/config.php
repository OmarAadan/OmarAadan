<?php
// Database configuration
$host = "localhost";
$dbname = "electronic shop";
$username = "root";
$password = "";

try {
    $shop_db = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $shop_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die();
}
?>
