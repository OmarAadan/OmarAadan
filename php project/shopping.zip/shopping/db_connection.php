<?php
$servername = "localhost";
$username = "root";
$password = ""; // Replace with your actual database password
$db_name = "shop_e"; // Database name is "shopping"

// Create connection
$connection = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Uncomment the following line if you want to verify a successful connection
// echo "Connected successfully";
?>
