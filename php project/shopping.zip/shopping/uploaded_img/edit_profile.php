<!-- edit_profile.php -->
<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // If not logged in, redirect to the login page
    header('location: login.php');
    exit();
}

// Get user information from the session
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Process form submission (Update profile)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle the form submission to update user profile
    // Add your update logic here (update database, etc.)
    // Redirect back to the profile page after updating
    header('location: profile.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <!-- Include the Tailwind CSS file -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

</head>

<body class="bg-gray-100">
    <nav class="bg-gray-800 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a class="text-white text-2xl font-bold" href="index.php">Electronic Store</a>
            <div class="flex space-x-4">
                <a class="text-white" href="index.php">Home</a>
                <a class="text-white" href="dashboard.php">Dashboard</a>
                <a class="text-white" href="profile.php">Profile</a>
                <a class="text-white" href="products.php">Products</a>
                <a class="text-white" href="cart.php">
                    <i class="fa fa-shopping-cart"></i> Shopping Cart
                    <?php
                    $cartCount = !empty($_SESSION["shopping_cart"]) ? count($_SESSION["shopping_cart"]) : 0;
                    echo $cartCount > 0 ? '<span class="badge badge-danger">' . $cartCount . '</span>' : '';
                    ?>
                </a>
                <a class="text-white" href="aboutus.php">About Us</a>
                <span class="text-white">Welcome, <?php echo $username; ?>!</span>
                <a class="text-white" href="logout.php">Logout</a>
                <a class="text-white" href="login.php">Login</a>
                <a class="text-white" href="register.php">Register</a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto mt-8">
        <div class="max-w-md mx-auto bg-white p-8 rounded-md shadow-md">
            <h2 class="text-2xl font-bold mb-4">Edit Profile</h2>
            <!-- Add your form for editing profile information here -->
            <form action="edit_profile.php" method="post">
                <!-- Add form fields for updating profile -->
                <button type="submit" class="mt-4 block bg-blue-500 text-white py-2 px-4 rounded-md">Update Profile</button>
            </form>
            <p class="mt-4 text-gray-600">Go back to <a href="index.php" class="text-blue-500">Home</a></p>
        </div>
    </div>

    <footer class="bg-gray-800 text-white py-4 text-center">
        <div class="container mx-auto">
            &copy; 2023 published this Electronic shop | All rights reserved | Developed by Omar Adan and Zakaria Mahad
        </div>
    </footer>
</body>

</html>
