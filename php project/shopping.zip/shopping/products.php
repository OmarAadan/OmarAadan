<?php
session_start();

// Database connection parameters
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_NAME = 'shop_e';

// Create a secure connection
$connection = new mysqli($DB_HOST, $DB_USER, $DB_PASSWORD, $DB_NAME);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if (isset($_POST["add"])) {
    // Validate product ID
    $product_id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);
    if (!$product_id || $product_id < 1) {
        // Handle invalid product ID error
        die("Invalid product ID");
    }

    // Prepare SQL statements with prepared statements
    $sql_get_product = "SELECT * FROM products WHERE id = ?";
    $sql_update_cart = "UPDATE shopping_cart SET quantity = quantity + 1 WHERE product_id = ?";

    $stmt_get_product = $connection->prepare($sql_get_product);
    $stmt_update_cart = $connection->prepare($sql_update_cart);

    $stmt_get_product->bind_param("i", $product_id);
    $stmt_get_product->execute();

    $result = $stmt_get_product->get_result();

    if ($result->num_rows !== 1) {
        // Handle product not found error
        die("Product not found");
    }

    $product = $result->fetch_assoc();

    // Use prepared statements for updating cart quantity
    $stmt_update_cart->bind_param("i", $product_id);

    if (!isset($_SESSION["shopping_cart"]) || !array_key_exists($product_id, $_SESSION["shopping_cart"])) {
        $_SESSION["shopping_cart"][$product_id] = ["product_id" => $product_id, "quantity" => 1];
    } else {
        $stmt_update_cart->execute();
        $_SESSION["shopping_cart"][$product_id]["quantity"]++;
    }

    // Close statements and result
    $stmt_get_product->close();
    $stmt_update_cart->close();
    $result->close();

    header("Location: products.php");
    exit();
}

// Fetch products using secure prepared statements
$sql_get_products = "SELECT * FROM products ORDER BY id ASC";
$stmt_get_products = $connection->prepare($sql_get_products);
$stmt_get_products->execute();
$result = $stmt_get_products->get_result();

// Close connection
$connection->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .product .image-container {
            height: 320px; /* Adjust the height as needed */
        }

        .product .image-container img {
            width: 116%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head>

<body class="bg-gray-100">

    <nav class="bg-gray-800 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a class="text-white text-2xl font-bold" href="index.php">Electronic</a>
            <div class="flex space-x-4">
                <a class="text-white" href="home.php">Home</a>
                <a class="text-white" href="products.php">Products</a>
                <a class="text-white" href="cart.php">
                    <i class="fa fa-shopping-cart"></i>
                    Shopping Cart
                    <?php
                    $cartCount = !empty($_SESSION["shopping_cart"]) ? count($_SESSION["shopping_cart"]) : 0;
                    echo $cartCount > 0 ? '<span class="badge badge-danger">' . $cartCount . '</span>' : '';
                    ?>
                </a>
                <a class="text-white" href="aboutus.php">About Us</a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_array()) {
        ?>
                <form method="post" action="products.php?action=add&id=<?php echo $row["id"]; ?>" class="col-span-1 md:col-span-1/3">
                    <div class="product bg-white p-4 rounded-lg">
                        <div class="image-container h-40 mb-4 overflow-hidden">
                            <!-- Use object-cover to ensure the image covers the entire box -->
                            <img src="<?php echo $row["image_url"]; ?>" alt="<?php echo $row["description"]; ?>" class="w-full h-full object-cover">
                        </div>
                        <h5 class="text-info text-lg font-semibold"><?php echo $row["description"]; ?></h5>
                        <h5 class="text-danger text-lg font-semibold">$<?php echo $row["price"]; ?></h5>
                        <div class="flex justify-between mt-4">
                            <input type="number" name="quantity" value="1" min="1" class="w-1/2 border p-2">
                            <button type="submit" name="add" class="bg-green-500 text-white px-4 py-2 rounded-full hover:bg-green-600">
                                <i class="fas fa-shopping-cart"></i> Add to Cart
                            </button>
                        </div>
                    </div>
                </form>
        <?php
            }
        }
        ?>
    </div>

    <footer class="bg-gray-800 text-white py-4 text-center">
        <div class="container mx-auto">
            &copy; 2023 published this Electronic shop | All rights reserved | Developed by Group Work Together
        </div>
    </footer>
</body>

</html>
