<?php
session_start();

// Check if the shopping cart is not empty
$shoppingCart = isset($_SESSION['shopping_cart']) ? $_SESSION['shopping_cart'] : [];

// Database connection parameters
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_NAME = 'shop_e';

// Create a secure connection
$connection = new mysqli($DB_HOST, $DB_USER, $DB_PASSWORD, $DB_NAME);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . htmlspecialchars($connection->connect_error));
}

// Handle remove item from cart
if (isset($_GET['action']) && $_GET['action'] == 'remove') {
    $removeProductId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if ($removeProductId) {
        // Remove the item from the shopping cart
        unset($_SESSION['shopping_cart'][$removeProductId]);

        // Set remove message
        $_SESSION['message'] = "Item removed successfully.";

        // Redirect back to the cart page
        header("Location: cart.php");
        exit();
    }
}

// Handle update item quantity
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updated = false;
    foreach ($_POST['quantity'] as $productId => $newQuantity) {
        $updateProductId = filter_var($productId, FILTER_VALIDATE_INT);
        $newQuantity = filter_var($newQuantity, FILTER_VALIDATE_INT);

        if ($updateProductId && $newQuantity > 0) {
            // Update the quantity for the specific item in the shopping cart
            $_SESSION['shopping_cart'][$updateProductId]['quantity'] = $newQuantity;
            $updated = true;
        }
    }

    // Redirect back to the cart page
    header("Location: cart.php");
    exit();
}

// Fetch product details for items in the shopping cart
$cartProducts = [];
foreach ($shoppingCart as $cartItem) {
    $product_id = $cartItem['product_id'];

    // Fetch product details using the product_id
    $sql_get_product = "SELECT * FROM products WHERE id = ?";
    $stmt_get_product = $connection->prepare($sql_get_product);
    $stmt_get_product->bind_param("i", $product_id);
    $stmt_get_product->execute();
    $result = $stmt_get_product->get_result();

    if ($result->num_rows == 1) {
        $cartProducts[] = [
            'product' => $result->fetch_assoc(),
            'quantity' => $cartItem['quantity']
        ];
    }

    // Close statement and result
    $stmt_get_product->close();
    $result->close();
}

// Check if there is a message to display
$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';

// Clear the message after displaying
unset($_SESSION['message']);

// Close connection
$connection->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script>
        function confirmRemove() {
            return confirm("Are you sure you want to remove this item?");
        }
    </script>
</head>

<body class="bg-gray-100">

    <nav class="bg-gray-800 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a class="text-white text-2xl font-bold" href="index.php">Electronic</a>
            <div class="flex space-x-4">
                <a class="text-white" href="home.php">Home</a>
                <a class="text-white" href="products.php">Products</a>
                <a class="text-white" href="cart.php">
                    <i class="fa fa-shopping-cart"></i>
                    Shopping Cart
                    <?php
                    $cartCount = count($shoppingCart);
                    echo $cartCount > 0 ? '<span class="badge badge-danger">' . $cartCount . '</span>' : '';
                    ?>
                </a>
                <a class="text-white" href="aboutus.php">About Us</a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto mt-8">
        <h1 class="text-3xl font-semibold mb-4">Shopping Cart</h1>

        <?php if (!empty($message)) : ?>
            <p class="<?php echo strpos($message, 'successfully') !== false ? 'text-green-500' : 'text-red-500'; ?>">
                <?php echo htmlspecialchars($message); ?>
            </p>
        <?php endif; ?>

        <?php if (empty($cartProducts)) : ?>
            <p>Your shopping cart is empty.</p>
        <?php else : ?>
            <form method="post" action="cart.php">
                <table class="w-full border-collapse border border-gray-300">
                    <thead>
                        <tr>
                            <th class="p-2 border">Product</th>
                            <th class="p-2 border">Price</th>
                            <th class="p-2 border">Quantity</th>
                            <th class="p-2 border">Total</th>
                            <th class="p-2 border">Remove Item</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cartProducts as $cartProduct) : ?>
                            <tr>
                                <td class="p-2 border">
                                    <?php echo htmlspecialchars($cartProduct['product']['description']); ?>
                                </td>
                                <td class="p-2 border">
                                    $<?php echo number_format($cartProduct['product']['price'], 2); ?>
                                </td>
                                <td class="p-2 border">
                                    <input type="text" name="quantity[<?php echo $cartProduct['product']['id']; ?>]" value="<?php echo $cartProduct['quantity']; ?>" min="1" class="w-16 text-center">
                                </td>
                                <td class="p-2 border">
                                    $<?php echo number_format($cartProduct['product']['price'] * $cartProduct['quantity'], 2); ?>
                                </td>
                                <td class="p-2 border">
                                    <a href="cart.php?action=remove&id=<?php echo $cartProduct['product']['id']; ?>" onclick="return confirmRemove();" class="text-red-500">
                                        Remove Item
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>    
                </div>
            </form>

            <p class="mt-4 font-semibold">Total: $<?php echo htmlspecialchars(calculateTotal($cartProducts)); ?></p>
        <?php endif; ?>
    </div>

    <?php
    function calculateTotal($cartProducts)
    {
        $total = 0;
        foreach ($cartProducts as $cartProduct) {
            $total += $cartProduct['product']['price'] * $cartProduct['quantity'];
        }
        return number_format($total, 2);
    }
    ?>

    <footer class="bg-gray-800 text-white py-4 text-center">
        <div class="container mx-auto">
            &copy; 2023 published this Electronic shop | All rights reserved | Developed by Group Work To Gether
        </div>
    </footer>
</body>

</html>
