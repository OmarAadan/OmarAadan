<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electronic Store Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-100">

<div class="flex h-screen">
    <!-- Sidebar -->
    <div class="w-1/4 bg-gray-800 text-white p-6 md:block" id="sidebar">
        <?php
        // Example: Set user type (you should replace this with your actual logic)
        $userType = 'admin'; // 'admin' or 'user'

        // Display sidebar links based on user type
        echo '<ul>';
        echo '<li><a href="index.php?page=login" class="block py-2">Login</a></li>';
        echo '<li><a href="index.php?page=home" class="block py-2">Home</a></li>';
        echo '<li><a href="index.php?page=dashboard" class="block py-2">Dashboard</a></li>';
        echo '<li><a href="index.php?page=products" class="block py-2">Products</a></li>';
        echo '<li><a href="index.php?page=cart" class="block py-2">Shopping Cart</a></li>';
        echo '<li><a href="index.php?page=aboutus" class="block py-2">About Us</a></li>';
        echo '</ul>';
        ?>
    </div>

    <!-- Content -->
    <div class="w-3/4 p-8">
        <?php
        // Include content based on the selected page
        $page = isset($_GET['page']) ? $_GET['page'] : 'home';

        // Check if the page is the dashboard
        if ($page === 'dashboard') {
            echo '<div class="text-2xl font-bold mb-4">';
            // Display different welcome messages for admin and user
            if ($userType === 'admin') {
                echo 'Welcome Admin! This is Your Dashboard Page';
            } else {
                echo 'Welcome User! This is Your Dashboard Page';
            }
            echo '</div>';

            echo '<ul class="list-disc pl-6">';
            // Display different links for admin and user
            if ($userType === 'admin') {
                echo '<li><a href="admin_dashboard.php" class="text-blue-500 hover:underline">Admin Home</a></li>';
                // Add more admin-specific links as needed
            } else {
                echo '<li><a href="user_home.php" class="text-blue-500 hover:underline">User Home</a></li>';
                echo '<li><a href="index.php?page=products" class="text-blue-500 hover:underline">Products</a></li>';
                echo '<li><a href="index.php?page=cart" class="text-blue-500 hover:underline">Shopping Cart</a></li>';
                echo '<li><a href="index.php?page=aboutus" class="text-blue-500 hover:underline">About Us</a></li>';
                // Add more user-specific links as needed
            }
            echo '</ul>';
        } else {
            // Display the content in an iframe for other pages
            echo '<iframe src="' . $page . '.php" width="100%" height="100%" frameborder="0"></iframe>';
        }
        ?>
    </div>
</div>

</body>
</html>
