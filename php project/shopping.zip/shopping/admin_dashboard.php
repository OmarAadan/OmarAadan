<!-- admin_dashboard.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... (same as before) ... -->
</head>
<body class="bg-gray-100">

<div class="flex h-screen">
    <!-- Sidebar -->
    <div class="w-1/4 bg-gray-800 text-white p-6 md:block" id="sidebar">
        <ul>
            <!-- ... (same as before) ... -->
        </ul>
    </div>

    <!-- Content -->
    <div class="w-3/4 p-8">
        <div class="text-2xl font-bold mb-4">Welcome Admin! This is Your Dashboard Page</div>
        
        <!-- User Profile Section -->
        <div class="mb-8">
            <h3 class="text-xl font-semibold mb-2">Admin Profile</h3>
            <p>Name: Admin Name</p>
            <p>Email: admin@example.com</p>
            <!-- Add more user profile details as needed -->
        </div>

        <!-- Admin-specific links -->
        <ul class="list-disc pl-6">
            <li><a href="admin_home.php" class="text-blue-500 hover:underline">Admin Home</a></li>
            <!-- Add more admin-specific links as needed -->
        </ul>
    </div>
</div>

</body>
</html>
