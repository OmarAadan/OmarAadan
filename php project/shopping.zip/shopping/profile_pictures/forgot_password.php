<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include("db.php");

// Initialize an array to store reset password errors
$reset_errors = array();

// Handle the form submission (if any)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate user input
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    // Check if the email exists in the database
    $select = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $select->execute([$email]);
    $result = $select->get_result();

    if ($result->num_rows > 0) {
        // Generate a unique and secure token
        $token = bin2hex(random_bytes(32));

        // Store the hashed token and its expiration time in the database
        $token_hash = password_hash($token, PASSWORD_DEFAULT);
        $token_expiry = strtotime('+1 hour'); // Set expiration to 1 hour from now

        $update = $conn->prepare("UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE email = ?");
        $update->execute([$token_hash, $token_expiry, $email]);

        if ($update) {
            // Send a password reset email to the user with the token
            $reset_link = "reset_password.php?token=$token";

            // Example email content
            $subject = "Password Reset";
            $message = "Click the following link to reset your password: $reset_link";
            $headers = "From: apdicumaraadan@gmail.com";

            // Uncomment the following line to send the email (replace placeholders)
            // mail($email, $subject, $message, $headers);

            // Redirect to a page indicating that an email has been sent
            header("Location: reset_email_sent.php");
            exit();
        } else {
            $reset_errors[] = "Failed to generate reset token.";
        }
    } else {
        $reset_errors[] = "Email not found. Please check your email and try again.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <!-- Include your CSS stylesheet link here -->
</head>
<body>

<?php
// Display reset password errors, if any
if (!empty($reset_errors)) {
    foreach ($reset_errors as $error) {
        echo '<div class="error">' . $error . '</div>';
    }
}
?>

<form action="forgot_password.php" method="post">
    <label for="email">Email:</label>
    <input type="email" name="email" required>
    <input type="submit" value="Submit">
</form>

</body>
</html>
