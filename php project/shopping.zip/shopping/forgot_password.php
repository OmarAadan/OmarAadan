<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forget Password</title>
    <!-- Include Tailwind CSS from CDN -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-900 text-white">
    <div class="flex items-center justify-center h-screen">
        <form class="bg-silver p-8 w-96" action="#" method="POST">
            <h1 class="text-2xl font-bold mb-4">Enter Your Name As Correct to Get Your Password</h1>
            <label class="block mb-2">Enter Your Name</label>
            <input type="text" name="raadi" class="w-full p-2 mb-4 bg-gray-800 border border-gray-700 rounded">
            <input type="submit" name="search" value="Search" class="w-full bg-white text-black p-2 rounded cursor-pointer">
            <br>
            <a href="login.php" class="text-white">Back to Login Form</a>
            <br>

            <?php
            $conn = mysqli_connect('localhost', 'root', '', 'shop_e'); 
            if (isset($_POST['search'])) {
                $raadi = $_POST['raadi'];

                $sql = "SELECT * FROM login WHERE fullname='$raadi'";
                $result = $conn->query($sql);

                while($row = $result->fetch_assoc()){
                    echo $row['password'];
                }
            }
            ?>
        </form>
    </div>
</body>
</html>
