<?php
// forgot_password.php

// Assuming you have a function to handle the password reset logic
function handlePasswordReset() {
    if (isset($_POST['submit'])) {
        $email = $_POST['email'];

        // Generate a unique reset token (you may use a better method)
        $resetToken = bin2hex(random_bytes(32));

        // Store the token in the database
        $conn = new mysqli("localhost", "root", "", "shop_e");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $updateTokenQuery = "UPDATE users SET reset_token = '$resetToken' WHERE email = '$email'";
        $conn->query($updateTokenQuery);

        // Send an email with a link containing the reset token
        // You should use a proper email library for this (e.g., PHPMailer)
        $resetLink = "http://yourwebsite.com/reset_password.php?token=$resetToken";

        mail($email, "Password Reset", "Click the following link to reset your password: $resetLink");

        echo "Password reset link sent to your email.";
    }
}

if (isset($_GET['token'])) {
    handlePasswordReset();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body>

<div class="max-w-md mx-auto">
    <h1 class="text-3xl font-bold mb-6">Forgot Password</h1>

    <form method="post" action="">
        <div class="mb-4">
            <label for="email" class="block text-sm font-semibold text-gray-600">Email:</label>
            <input type="text" name="email" id="email" required class="w-full px-4 py-2 border border-gray-300 rounded-md">
        </div>
        <div class="mb-4">
            <input type="submit" name="submit" value="Reset Password" class="bg-blue-500 text-white px-4 py-2 rounded-md cursor-pointer">
        </div>
    </form>
</div>

</body>
</html>
