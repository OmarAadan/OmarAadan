<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Electronic Store</title>
    <!-- Include the Tailwind CSS file -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- Add any additional stylesheets or scripts as needed -->
</head>


<body class="bg-gray-100">
    <!-- Your navigation bar code here -->
    <nav class="navbar p-4 bg-gray-700">
        <div class="container mx-auto flex justify-between items-center">
            <a class="text-white text-2xl font-bold" href="index.php">Electronic Store</a>
            <div class="flex space-x-4 ">
                <a class="text-white" href="index.php">Home</a>
                <a class="text-white" href="products.php">Products</a>
                <a class="text-white" href="cart.php">
                    <i class="fa fa-shopping-cart"></i> Shopping Cart
                    <?php
                    $cartCount = !empty($_SESSION["shopping_cart"]) ? count($_SESSION["shopping_cart"]) : 0;
                    echo $cartCount > 0 ? '<span class="badge badge-danger">' . $cartCount . '</span>' : '';
                    ?>
                </a>
                <a class="text-white" href="aboutus.php">About Us</a>
                <!-- Add Register and Login links -->
                <a class="text-white" href="register.php">Register</a>
                <a class="text-white" href="login.php">Login</a>
            </div>
        </div>
    </nav>
