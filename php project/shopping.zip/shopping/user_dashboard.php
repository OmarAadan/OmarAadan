<!-- user_dashboard.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... (same as before) ... -->
</head>
<body class="bg-gray-100">

<div class="flex h-screen">
    <!-- Sidebar -->
    <div class="w-1/4 bg-gray-800 text-white p-6 md:block" id="sidebar">
        <ul>
            <!-- ... (same as before) ... -->
        </ul>
    </div>

    <!-- Content -->
    <div class="w-3/4 p-8">
        <div class="text-2xl font-bold mb-4">Welcome User! This is Your Dashboard Page</div>
        
        <!-- User Profile Section -->
        <div class="mb-8">
            <h3 class="text-xl font-semibold mb-2">User Profile</h3>
            <p>Name: User Name</p>
            <p>Email: user@example.com</p>
            <!-- Add more user profile details as needed -->
        </div>

        <!-- User-specific links -->
        <ul class="list-disc pl-6">
            <li><a href="user_home.php" class="text-blue-500 hover:underline">User Home</a></li>
            <li><a href="index.php?page=products" class="text-blue-500 hover:underline">Products</a></li>
            <li><a href="index.php?page=cart" class="text-blue-500 hover:underline">Shopping Cart</a></li>
            <li><a href="index.php?page=aboutus" class="text-blue-500 hover:underline">About Us</a></li>
            <!-- Add more user-specific links as needed -->
        </ul>
    </div>
</div>

</body>
</html>
