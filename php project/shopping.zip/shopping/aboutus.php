<!-- aboutus.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <!-- Include the Tailwind CSS file -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- Include FontAwesome CSS (Replace with the actual path if not using CDN) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Add your additional styles here */
        .rounded-circle {
            border-radius: 50%;
        }
    </style>
</head>

<body class="bg-gray-100">
    <!-- Your navigation bar code here -->
    <nav class="bg-gray-800 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a class="text-white text-2xl font-bold" href="index.php">Electronic shop</a>
            <div class="flex space-x-4">
                <a class="text-white" href="home.php">Home</a>
                <a class="text-white" href="products.php">Products</a>
                <a class="text-white" href="cart.php">
                    <i class="fa fa-shopping-cart"></i> Shopping Cart
                    <?php
                    $cartCount = !empty($_SESSION["shopping_cart"]) ? count($_SESSION["shopping_cart"]) : 0;
                    echo $cartCount > 0 ? '<span class="badge badge-danger">' . $cartCount . '</span>' : '';
                    ?>
                </a>
                <a class="text-white" href="aboutus.php">About Us</a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto mt-8">
        <h2 class="text-4xl font-bold my-8">Electronic Shop</h2>

        <!-- Welcome Section -->
        <div class="mb-8">
            <h3 class="text-2xl font-bold mb-4">Welcome to Our Electronic Shop!</h3>
            <p class="text-gray-600">
                At Electronic Shop, we strive to provide you with the latest and greatest in electronic devices. Explore
                our range of cutting-edge phones, laptops, and more. Your journey to innovation begins here!
            </p>
        </div>

        <!-- Vision and Mission Section -->
        <div class="mb-8 relative" style="background-color: #123456; position: relative;">
            <div class="absolute inset-0 bg-black opacity-50"></div>
            <div class="relative z-10 text-white p-8">
                <h3 class="text-2xl font-bold mb-4">Our Vision</h3>
                <p class="text-gray-200">
                    To become the preferred destination for high-quality electronic devices, providing cutting-edge phones
                    and laptops that empower our customers' lifestyles with innovation and excellence in service.
                </p>
            </div>
            <div class="absolute inset-0 bg-black opacity-50" style="mix-blend-mode: multiply;"></div>
        </div>

        <div class="mb-8 relative" style="background-color: #123456; position: relative;">
            <div class="absolute inset-0 bg-black opacity-50"></div>
            <div class="relative z-10 text-white p-8">
                <h3 class="text-2xl font-bold mb-4">Our Mission</h3>
                <p class="text-gray-200">
                    We are dedicated to offering a diverse range of top-notch phones and laptops, delivering exceptional
                    value and satisfaction to our customers while fostering a culture of continuous improvement and
                    technological advancement.
                </p>
            </div>
            <div class="absolute inset-0 bg-black opacity-50" style="mix-blend-mode: multiply;"></div>
        </div>
        <!-- Core Values Section -->
<div class="mb-8 relative" style="background-color: #123456; position: relative;">
    <div class="absolute inset-0 bg-black opacity-50"></div>
    <div class="relative z-10 text-white p-8">
        <h3 class="text-2xl font-bold mb-4">Core Values</h3>
        <ul class="list-disc list-inside text-gray-200">
            <li>Innovation</li>
            <li>Customer Satisfaction</li>
            <li>Continuous Improvement</li>
            <li>Integrity</li>
            <li>Teamwork</li>
        </ul>
    </div>
    <div class="absolute inset-0 bg-black opacity-50" style="mix-blend-mode: multiply;"></div>
</div>


        <!-- Team Section -->
        <h3 class="text-2xl font-bold mb-8">Meet Our Team</h3>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <!-- Team member 1 -->
            <div class="bg-white p-4 rounded-lg shadow-md text-center">
                <img src="/SHOPPING/images/omar.jpg" alt="Omar Adan" class="w-32 h-32 object-cover mx-auto rounded-circle mb-4">
                <h3 class="text-xl font-bold mb-2">Omar Adan</h3>
                <p class="text-gray-600">Developer</p>
            </div>

            <!-- Team member 2 -->
            <div class="bg-white p-4 rounded-lg shadow-md text-center">
                <img src="/SHOPPING/images/abdisalan.jpg" alt="Abdisan Adan" class="w-32 h-32 object-cover mx-auto rounded-circle mb-4">
                <h3 class="text-xl font-bold mb-2">Abdisan Adan</h3>
                <p class="text-gray-600">Graphic Designer</p>
            </div>

            <!-- Team member 3 -->
            <div class="bg-white p-4 rounded-lg shadow-md text-center">
                <img src="/SHOPPING/images/cawaale.jpg" alt="Mohamed Abdul" class="w-32 h-32 object-cover mx-auto rounded-circle mb-4">
                <h3 class="text-xl font-bold mb-2">Mohamed Abdul</h3>
                <p class="text-gray-600">Front-end Developer</p>
            </div>

            <!-- Team member 4 -->
            <div class="bg-white p-4 rounded-lg shadow-md text-center">
            <img src="/SHOPPING/images/zakaria.jpeg" alt="Zakaria Mahad" class="w-32 h-32 object-cover mx-auto rounded-circle mb-4">
                <h3 class="text-xl font-bold mb-2">Zakaria Mahad</h3>
                <p class="text-gray-600">Full stack Developer</p>
            </div>
        </div>
        <p class="text-gray-600">
                Have questions or need assistance? Feel free to contact us at the following number:
            </p>
            <p class="text-2xl font-bold text-gray-800">(+252):612197944</p>
   
    </div>
    <footer class="bg-gray-800 text-white py-4 text-center">
    <div class="container mx-auto">
    &copy; 2023 published this Electronic shop | All rights reserved | Developed by Group Work To Gether
    </div>
</footer>
</body>

</html>
