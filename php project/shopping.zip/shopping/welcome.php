<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Welcome</title>

   <!-- Include Tailwind CSS -->
   <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

   <!-- Custom styles -->
   <style>
      /* Add any additional custom styles here */
   </style>
</head>
<body class="bg-gray-100 h-screen flex items-center justify-center">

   <div class="bg-white p-8 rounded-md shadow-md max-w-md w-full">
      <h3 class="text-2xl font-semibold mb-4">Welcome, <?php echo $_SESSION['username']; ?>!</h3>
      <p class="text-gray-600">You are now logged in.</p>
      <p class="mt-4"><a href="logout.php" class="text-blue-500">Logout</a></p>
   </div>

</body>
</html>
