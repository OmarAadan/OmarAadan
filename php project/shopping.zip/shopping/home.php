<?php
session_start();
$db_name = "shop_e";
$connection = mysqli_connect("localhost", "root", "", $db_name);

// Check if a user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    
    // Fetch user details from the database based on the user ID
    $query = "SELECT username, profile_picture FROM login WHERE id = '$userId'";
    $result = mysqli_query($connection, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $username = $user['username'];
        $profilePicture = $user['profile_picture'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electronic Store</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <!-- Include the Tailwind CSS file -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .image-preview {
            max-width: 100%;
            max-height: 100%;
            cursor: pointer;
            transition: transform 0.2s ease-in-out;
        }

        .image-preview:hover {
            transform: scale(1.05);
        }
    </style>
</head>

<body class="bg-gray-100">
    <nav class="bg-gray-800 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a class="text-white text-2xl font-bold" href="index.php">Electronic Store</a>
            <div class="flex space-x-4">
                <?php if (isset($username)) : ?>
                    <!-- Display profile information for logged-in user -->
                    <div class="flex items-center text-white">
                        <img src="<?php echo $profilePicture; ?>" alt="Profile Picture" class="h-6 w-6 rounded-full mr-2">
                        <span><?php echo $username; ?></span>
                    </div>
                    <a class="text-white" href="logout.php">Logout</a>
                <?php else : ?>
                    <!-- If no user is logged in, show login link -->
                    
                <?php endif; ?>
                <a class="text-white" href="home.php">Home</a>
                <a class="text-white" href="products.php">Products</a>
                <a class="text-white" href="cart.php">
                    <i class="fa fa-shopping-cart"></i> Shopping Cart
                    <?php
                    $cartCount = !empty($_SESSION["shopping_cart"]) ? count($_SESSION["shopping_cart"]) : 0;
                    echo $cartCount > 0 ? '<span class="badge badge-danger">' . $cartCount . '</span>' : '';
                    ?>
                </a>
                <a class="text-white" href="aboutus.php">About Us</a>
                <a class="text-white" href="logout.php">logout</a>

            </div>
        </div>
        
    </nav>

    <div class="container mx-auto mt-8">
        <h2 class="text-4xl font-bold my-8">Welcome to Electronic Store</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php
            $imageUrls = [
                "computer6.jpg",
                "computer7.jpg",
                "computer8.jpg",
            ];

            foreach ($imageUrls as $imageUrl) {
            ?>
                <div class="col-span-1">
                    <div class="product border rounded p-4 text-center h-95">
                        <img src="<?php echo $imageUrl; ?>" alt="Product Image" class="w-full h-64 object-cover mb-4 image-preview">
                        <h5 class="text-info text-lg font-semibold">Product Description</h5>
                        <br>
                        <!-- Use Tailwind CSS classes for styling the button -->
                        <a href="products.php" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Go to products
                        </a>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </div>
    <footer class="bg-gray-800 text-white py-4 text-center">
        <div class="container mx-auto">
            &copy; 2023 published this Electronic shop | All rights reserved | Developed by Group Work To Gether
        </div>
    </footer>
</body>

</html>
