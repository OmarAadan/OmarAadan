<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style>
        .login {
            width: 460px;
            margin: 58px auto;
            font-family: Georgia;
            border-radius: 10px;
            border: 2px solid #009;
            padding: 10px 40px 10px;
            margin-top: 100px;
        }

        input[type="text"],
        input[type="password"] {
            width: 90%;
            padding: 5px;
            margin-top: 2px;
            margin-bottom: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            padding-left: 5px;
            font-size: 16px;
            font-family: Georgia;
        }

        input[type="submit"] {
            width: 100%;
            background-color: #fff;
            color: #009;
            border: 2px solid #009;
            padding: 7px;
            font-size: 20px;
            cursor: pointer;
            border-radius: 5px;
            margin-bottom: 5px;
            font-weight: bold;
        }

        label {
            font-weight: bold;
        }

        h1 {
            text-align: center;
        }

        span {
            color: red;
            text-align: center;
            display: block;
        }

        a {
            padding-left: 20px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<?php
session_start();
$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Your database connection code goes here
    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "shop_e"; // Change this if your database name is different

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $sql = "SELECT * FROM login WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // Successful login
        if (isset($_POST['rememberme'])) {
            // Set cookies
            setcookie("username", $username, time() + 60 * 60 * 24 * 30 * 3);
            setcookie("password", $password, time() + 60 * 60 * 24 * 30 * 3);
        }
    
        $_SESSION['username'] = $username;
        header("Location: home.php"); // Use a relative path
        exit();
    } else {
        $message = "Invalid username or password";
    }
    

    $stmt->close();
    $conn->close();
}
?>

<div class="login">
    <h1>Login Form</h1>
    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" value="<?php echo isset($_COOKIE['username']) ? $_COOKIE['username'] : ""; ?>" required>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" value="<?php echo isset($_COOKIE['password']) ? $_COOKIE['password'] : ""; ?>" required>
</br>
        <input type="checkbox" name="rememberme" value="1" id="rememberme">
        <label for="rememberme">Remember me</label>

        <a href="forgot_password.php">Forgot Password</a>
        <a href="signup.php">Signup</a>

        <br><br>
        <input type="submit" name="submit" value="Login">
    </form>
    <?php echo "<span>$message</span>"; ?>
</div>

</body>
</html>

